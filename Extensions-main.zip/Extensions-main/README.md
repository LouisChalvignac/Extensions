# Extension de nettoyage Web #
Cette extension vous permet de supprimer manuellement d'une page des élements de cette dernière
Les changements sont durable entre les connexions au sites et sont listés dans l'onglet Sites nettoyé de l'extension
Vous pouvez changer à tout moment de manière individuelle chaque éléments déjà bloqué 

# Installation #
Cette extension est compatible avec Chrome 

1. Aller dans le menu Gerer les extensions dans Chrome
2. Activer le mode développeur
3. Telecharger en zip le répertoire main
4. Extraire l'archive à l'endroit de votre choix (de préférence facile d'accès)
5. Sur le menu Gerer les extensions de Chrome, cliquer sur Charger l'extension non empaquetée
6. Selectionner le dossier que vous avez extrait de l'archive
7. L'extension est installée, ne désactivez pas le mode développeur si vous voulez continuer à utiliser l'extension
    

# Note #
Les données sont stockées de manières locales dans local.storage
La branche Partie 3 contient une version antèrieure du code, l'extension dans cette branche n'est potentiellement pas fonctionnelle 
